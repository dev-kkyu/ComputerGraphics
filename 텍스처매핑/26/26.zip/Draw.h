#pragma once
#include "Header.h"
#include "Cube.h"
#include "Pyramid.h"
#include "Light.h"
#include "Circle.h"

GLvoid drawScene();
