#include "KeyboardUP.h"

GLvoid KeyboardUP(unsigned char key, int x, int y)
{
	switch (key) {
	}
}

GLvoid SpecialKeyboardUP(int key, int x, int y)
{
	switch (key) {
	case GLUT_KEY_LEFT:
		break;
	case GLUT_KEY_RIGHT:
		break;
	case GLUT_KEY_UP:
		break;
	case GLUT_KEY_DOWN:
		break;
	}
}
