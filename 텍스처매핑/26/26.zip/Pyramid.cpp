#include "Pyramid.h"

Pyramid::Pyramid()
{
	Color = glm::vec3(0, 1, 0);
}

void Pyramid::FixUpdate()
{
	glm::mat4 Trans = glm::translate(Unit, glm::vec3(0, 1, 0));
	Change = Trans;

	Rotate = glm::rotate(Unit, glm::radians(O_RotYAngle), glm::vec3(0, 1, 0));
}

void Pyramid::Draw()
{
	glBindVertexArray(pyramidVAO);

	GLuint selectColorLocation = glGetUniformLocation(shaderID, "selectColor");	//--- �ؽ�ó ���
	glUniform1i(selectColorLocation, 1);

	GLuint model = glGetUniformLocation(shaderID, "modelTransform");
	glUniformMatrix4fv(model, 1, GL_FALSE, glm::value_ptr(Change));


	for (int i = 0; i < 6; ++i) {
		glBindTexture(GL_TEXTURE_2D, skTexture[i]);
		glDrawArrays(GL_TRIANGLES, i * 3, 3);
	}
}
