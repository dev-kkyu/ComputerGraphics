#pragma once
#include "Header.h"
#include "World.h"

GLvoid drawScene();

void resetView();
void drawLine();

void normalView();
void topView();
