#pragma once
#include "Header.h"

GLvoid KeyboardUP(unsigned char key, int x, int y);
GLvoid SpecialKeyboardUP(int key, int x, int y);