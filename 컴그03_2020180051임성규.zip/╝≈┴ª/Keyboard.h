#pragma once
#include "Header.h"
#include "World.h"

GLvoid Keyboard(unsigned char key, int x, int y);
GLvoid SpecialKeyboard(int key, int x, int y);

extern World newWorld;