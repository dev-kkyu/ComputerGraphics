#pragma once
#include "Header.h"
#include "World.h"

GLvoid TimerFunction(int value);

extern World newWorld;
