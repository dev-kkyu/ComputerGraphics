#include "Cube.h"

Cube::Cube() : Unit(glm::mat4(1.f))
{
}

Cube::Cube(glm::vec3 Position, float Xscale, float Zscale)
	: Unit(glm::mat4(1.f)), Position(Position), Xscale(Xscale), Zscale(Zscale), isRender(true)		//Position�� y�� 0���� �����Ѵ�.
{
	random_device rd;
	default_random_engine dre(rd());
	uniform_real_distribution<float> Curd{ 0.f, 1.f };
	Color = glm::vec3(Curd(dre), Curd(dre), Curd(dre));
	//Color = glm::vec3(203/255., 175/255., 1.f);

	uniform_real_distribution<float> maxSurd{ 5.f, 15.f };
	maxScale = maxSurd(dre);

	uniform_real_distribution<float> Surd{ 0.f, maxScale };
	Yscale = Surd(dre);

	uniform_int_distribution<int> Durd{ 0, 1 };
	Direction = Durd(dre);
	if (!Direction)
		Direction = -1;		//-1 �Ǵ� 1�� ����

	uniform_real_distribution<float> speedUrd{ 0.05f, 0.1f };
	speed = speedUrd(dre);

	Update();

}

Cube::~Cube()
{
}

void Cube::FixUpdate()
{

}

void Cube::Update()
{
	if (isUpDownMove) {
		glm::mat4 Scale;
		glm::mat4 Trans;

		if (Yscale <= 0.f)
			Direction = 1;
		else if (Yscale >= maxScale)
			Direction = -1;

		Yscale += speed * Direction * MoveSpeed;


		Trans = glm::translate(Unit, glm::vec3(0, 1, 0));
		Scale = glm::scale(Unit, glm::vec3(Xscale, Yscale, Zscale));

		Change = Scale * Trans;

		Trans = glm::translate(Unit, Position);

		Change = Trans * Change;
	}
	else if (isMoveStopNDown) {
		glm::mat4 Scale;
		glm::mat4 Trans;

		if (maxScale / 5 < Yscale)
			Yscale -= speed;


		Trans = glm::translate(Unit, glm::vec3(0, 1, 0));
		Scale = glm::scale(Unit, glm::vec3(Xscale, Yscale, Zscale));

		Change = Scale * Trans;

		Trans = glm::translate(Unit, Position);

		Change = Trans * Change;
	}
}

void Cube::Draw()
{
	if (isRender) {
		glBindVertexArray(VAO);

		GLuint Color = glGetUniformLocation(shaderID, "objectColor");
		glUniform3f(Color, this->Color.r, this->Color.g, this->Color.b);

		GLuint modelLocation = glGetUniformLocation(shaderID, "modelTransform");
		glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(Change)); //--- modelTransform ������ ��ȯ

		glDrawArrays(GL_TRIANGLES, 0, 36);
	}
}

void Cube::SetRender(bool isRender)
{
	this->isRender = isRender;
}

bool Cube::GetRender()
{
	return isRender;
}

float Cube::getLeft()
{
	return Position.x - Xscale;
}

float Cube::getRight()
{
	return Position.x + Xscale;
}

float Cube::getBehind()
{
	return Position.z - Zscale;
}

float Cube::getFront()
{
	return Position.z + Zscale;
}

float Cube::getBottom()
{
	return 0.0f;
}

float Cube::getTop()
{
	return 2.0f;
}
